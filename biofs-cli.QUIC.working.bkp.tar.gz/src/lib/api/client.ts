import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import { CONFIG } from '../config/constants';
import { CredentialsManager } from '../auth/credentials';
import { ApiResponse, FileInfo, FileWithURL, IPAsset, Biosample } from '../../types/api';
import { Logger } from '../utils/logger';

export class GenoBankAPIClient {
  private static instance: GenoBankAPIClient;
  private axios: AxiosInstance;
  private credManager: CredentialsManager;

  private constructor() {
    this.credManager = CredentialsManager.getInstance();
    this.axios = axios.create({
      baseURL: CONFIG.API_BASE_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

  static getInstance(): GenoBankAPIClient {
    if (!GenoBankAPIClient.instance) {
      GenoBankAPIClient.instance = new GenoBankAPIClient();
    }
    return GenoBankAPIClient.instance;
  }

  public async getSignature(): Promise<string> {
    const creds = await this.credManager.loadCredentials();
    if (!creds) {
      throw new Error('Not authenticated. Please run "genobank login" first.');
    }
    return creds.user_signature;
  }

  // Authentication
  async recover(signature: string): Promise<{ wallet: string }> {
    const response = await this.axios.get('/recover', {
      params: { signature }
    });
    return response.data;
  }

  async validateRootUser(signature: string): Promise<boolean> {
    try {
      const response = await this.axios.get('/validate_root_user', {
        params: { signature }
      });
      return response.data.status === 'Success';
    } catch {
      return false;
    }
  }

  // Files
  async getMyUploadedFileList(): Promise<FileInfo[]> {
    const signature = await this.getSignature();
    const response = await this.axios.get<ApiResponse<FileInfo[]>>('/get_my_uploaded_file_list', {
      params: { user_signature: signature }
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || [];
    }
    throw new Error(response.data.status_details?.message || 'Failed to get file list');
  }

  async getMyUploadedFilesUrls(filter?: string): Promise<FileWithURL[]> {
    const signature = await this.getSignature();
    const params: any = { user_signature: signature };
    if (filter) params._filter = filter;

    try {
      const response = await this.axios.get<ApiResponse<FileWithURL[]>>('/get_my_uploaded_files_urls', {
        params
      });

      if (response.data.status === 'Success') {
        return response.data.status_details?.data || [];
      }
      // Return empty array if failed instead of throwing
      return [];
    } catch (error) {
      // Return empty array on error - user might not have files yet
      return [];
    }
  }

  async getPresignedLink(s3Path: string): Promise<string> {
    // Use the working endpoint from cravat.genobank.app (stream_s3_file)
    // This endpoint is proven to work with genobank-biofiles-stream.js
    const signature = await this.getSignature();
    const streamUrl = `/api_vcf_annotator/stream_s3_file?user_signature=${encodeURIComponent(signature)}&file_path=${encodeURIComponent(s3Path)}`;
    return streamUrl;
  }

  async streamFile(filename: string, fileType?: string): Promise<string> {
    const signature = await this.getSignature();
    const params: any = {
      user_signature: signature,
      filename
    };
    if (fileType) params.file_type = fileType;

    // Return the stream URL
    return `${CONFIG.API_BASE_URL}/stream_file?${new URLSearchParams(params).toString()}`;
  }

  async uploadDatasetChunk(
    chunk: Buffer,
    metadata: {
      filename: string;
      chunkIndex: number;
      totalChunks: number;
      fileType?: string;
    }
  ): Promise<void> {
    const signature = await this.getSignature();
    const FormData = require('form-data');
    const form = new FormData();

    form.append('user_signature', signature);
    form.append('filename', metadata.filename);
    form.append('chunk_index', metadata.chunkIndex.toString());
    form.append('total_chunks', metadata.totalChunks.toString());
    if (metadata.fileType) {
      form.append('file_type', metadata.fileType);
    }
    form.append('chunk', chunk, {
      filename: `chunk_${metadata.chunkIndex}`
    });

    await this.axios.post('/upload_dataset_chunk', form, {
      headers: form.getHeaders()
    });
  }

  // Story Protocol
  async getStoryIPAssets(): Promise<IPAsset[]> {
    try {
      const signature = await this.getSignature();
      Logger.debug('Calling get_story_ip_assets...');

      const response = await this.axios.get('/get_story_ip_assets', {
        params: { user_signature: signature }
      });

      if (response.data.status === 'Success') {
        // The API returns story_ips[] and ip_assets[] arrays, combine them
        const storyIPs = response.data.story_ips || [];
        const ipAssets = response.data.ip_assets || [];
        const allAssets = [...storyIPs, ...ipAssets];

        Logger.debug(`✅ Found ${allAssets.length} Story IP assets (${storyIPs.length} story_ips + ${ipAssets.length} ip_assets)`);
        return allAssets;
      }

      Logger.debug('⚠️ get_story_ip_assets returned non-success status');
      return [];
    } catch (error) {
      Logger.debug(`❌ Error fetching Story IP assets: ${error}`);
      return [];
    }
  }

  // Avalanche Biosamples
  async getAvalancheBiosamples(): Promise<any[]> {
    try {
      Logger.debug('Calling /biosamples?chainID=43113...');

      const response = await this.axios.get('/biosamples', {
        params: { chainID: 43113 }
      });

      let allBiosamples: any[] = [];
      if (Array.isArray(response.data)) {
        allBiosamples = response.data;
      } else if (response.data.biosamples && Array.isArray(response.data.biosamples)) {
        allBiosamples = response.data.biosamples;
      } else if (response.data.data && Array.isArray(response.data.data)) {
        allBiosamples = response.data.data;
      }

      // Filter for user's biosamples (we'll need wallet address)
      const creds = await this.credManager.loadCredentials();
      const userWallet = creds?.wallet_address?.toLowerCase();

      const userBiosamples = userWallet
        ? allBiosamples.filter(b => b.owner_address?.toLowerCase() === userWallet)
        : [];

      Logger.debug(`✅ Found ${userBiosamples.length} Avalanche biosamples`);
      return userBiosamples;
    } catch (error) {
      Logger.debug(`❌ Error fetching Avalanche biosamples: ${error}`);
      return [];
    }
  }

  async mintVariantsStoryNFT(metadata: {
    filename: string;
    s3_path?: string;
    ipfs_hash?: string;
    collection_address?: string;
  }): Promise<{ ipId: string; txHash: string }> {
    const signature = await this.getSignature();
    const response = await this.axios.post<ApiResponse>('/mint_variants_story_nft', {
      user_signature: signature,
      ...metadata
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data;
    }
    throw new Error('Failed to mint NFT');
  }

  // Biosamples
  async getMyActiveBiosamples(): Promise<Biosample[]> {
    const signature = await this.getSignature();
    const response = await this.axios.get<ApiResponse<Biosample[]>>('/my_active_biosamples', {
      params: { user_signature: signature }
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || [];
    }
    throw new Error('Failed to get biosamples');
  }

  async getBiosampleDetails(serial: string): Promise<Biosample> {
    const response = await this.axios.get<ApiResponse<Biosample>>('/biosample_details', {
      params: { biosample_serial: serial }
    });

    if (response.data.status === 'Success' && response.data.status_details?.data) {
      return response.data.status_details.data;
    }
    throw new Error('Failed to get biosample details');
  }

  // BioIP specific endpoints
  async getMyBioIPs(): Promise<any[]> {
    try {
      const signature = await this.getSignature();
      const response = await this.axios.get('/api_bioip/get_my_bioips', {
        params: { user_signature: signature }
      });
      return response.data.status_details?.bioips || response.data.bioips || response.data.data || [];
    } catch (error) {
      console.error('Error fetching BioIPs:', error);
      return [];
    }
  }

  async getMyGrantedBioIPs(): Promise<any[]> {
    try {
      const signature = await this.getSignature();

      // Debug logging to diagnose granted files issue
      Logger.debug('Calling get_my_granted_bioips...');
      Logger.debug(`Signature preview: ${signature.substring(0, 30)}...`);

      const response = await this.axios.get('/api_bioip/get_my_granted_bioips', {
        params: { user_signature: signature }
      });

      Logger.debug(`API Response status: ${response.data.status}`);
      Logger.debug(`Full response: ${JSON.stringify(response.data, null, 2)}`);

      const granted = response.data.status_details?.granted_bioips || response.data.granted_bioips || [];
      Logger.debug(`Parsed granted BioIPs count: ${granted.length}`);

      if (granted.length > 0) {
        Logger.debug(`First granted file: ${JSON.stringify(granted[0], null, 2)}`);
      }

      return granted;
    } catch (error: any) {
      Logger.debug(`Error fetching granted BioIPs: ${error}`);
      if (error?.response) {
        Logger.debug(`Error response: ${JSON.stringify(error.response.data)}`);
      }
      return [];
    }
  }

  async getBioIPDownloadURL(ipId: string): Promise<any> {
    const signature = await this.getSignature();

    // Use check_my_access endpoint instead - it's simpler and handles licensed access
    Logger.debug(`Checking access for IP Asset ${ipId}`);
    Logger.debug(`User signature: ${signature.substring(0, 20)}...`);

    const response = await this.axios.get('/api_bioip/check_my_access', {
      params: {
        user_signature: signature,
        ip_id: ipId
      }
    });

    Logger.debug(`Response status: ${response.data.status}`);
    Logger.debug(`Full response: ${JSON.stringify(response.data, null, 2)}`);

    if (response.data.status === 'Success' && response.data.status_details) {
      const details = response.data.status_details;

      if (!details.has_access) {
        throw new Error(details.reason || 'Access denied to this BioIP asset');
      }

      // Return in expected format
      return {
        access_granted: true,
        presigned_url: details.presigned_url,
        s3_path: details.s3_path,
        filename: details.filename || details.file_name
      };
    }
    throw new Error(response.data.status_details?.message || 'Failed to check access');
  }

  // Story PIL Access Control (GDPR Consent via License Tokens)
  async requestLicenseToken(ipId: string, licenseType: string = 'non-commercial', message?: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/api_bioip/request_license_token', {
      user_signature: signature,
      ip_id: ipId,
      license_type: licenseType,
      message: message || 'Request access for research purposes'
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || response.data;
    }
    throw new Error(response.data.status_details?.message || 'License token request failed');
  }

  async grantLicenseToken(requestId: string, receiverWallet: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/api_bioip/grant_license_token', {
      user_signature: signature,
      request_id: requestId,
      receiver_wallet: receiverWallet
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || response.data;
    }
    throw new Error(response.data.status_details?.message || 'License token minting failed');
  }

  async directGrantLicenseToken(ipId: string, receiverWallet: string, licenseType: string = 'non-commercial'): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/api_bioip/direct_grant_license_token', {
      user_signature: signature,
      ip_id: ipId,
      receiver_wallet: receiverWallet,
      license_type: licenseType
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || response.data;
    }
    throw new Error(response.data.status_details?.message || 'Direct grant failed');
  }

  async revokeLicenseToken(ipId: string, receiverWallet: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/api_bioip/revoke_license_token', {
      user_signature: signature,
      ip_id: ipId,
      receiver_wallet: receiverWallet
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || response.data;
    }
    throw new Error(response.data.status_details?.message || 'License token revocation failed');
  }

  async getPendingLicenseRequests(ipId?: string): Promise<any[]> {
    try {
      const signature = await this.getSignature();
      const params: any = { user_signature: signature };
      if (ipId) {
        params.ip_id = ipId;
      }
      const response = await this.axios.get('/api_bioip/get_pending_license_requests', { params });
      return response.data.status_details?.requests || response.data.status_details?.data?.requests || response.data.requests || [];
    } catch (error) {
      return [];
    }
  }

  async getActiveLicenseTokens(ipId?: string): Promise<any[]> {
    try {
      const signature = await this.getSignature();
      const params: any = { user_signature: signature };
      if (ipId) {
        params.ip_id = ipId;
      }
      const response = await this.axios.get('/api_bioip/get_active_license_tokens', { params });
      return response.data.status_details?.tokens || response.data.status_details?.data?.tokens || response.data.tokens || [];
    } catch (error) {
      return [];
    }
  }

  async checkMyAccess(ipId: string): Promise<any> {
    try {
      const signature = await this.getSignature();
      const response = await this.axios.get('/api_bioip/check_my_access', {
        params: {
          user_signature: signature,
          ip_id: ipId
        }
      });
      return response.data.status_details || response.data;
    } catch (error) {
      throw new Error('Failed to check access');
    }
  }

  // Legacy biosample methods (kept for backward compatibility)
  async requestBiosampleAccess(bioassetSerial: string, message?: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/request_biosample', {
      user_signature: signature,
      biosample_serial: bioassetSerial,
      message: message || 'Request access for research purposes'
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || response.data;
    }
    throw new Error(response.data.status_details?.message || 'Access request failed');
  }

  async approveBiosampleRequest(requestId: string, permitteeAddress: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/approve_biosample_request', {
      user_signature: signature,
      request_id: requestId,
      permittee_address: permitteeAddress
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || response.data;
    }
    throw new Error(response.data.status_details?.message || 'Approval failed');
  }

  async revokeBiosampleAccess(bioassetSerial: string, permitteeAddress: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/revoke_biosample_request', {
      user_signature: signature,
      biosample_serial: bioassetSerial,
      permittee_address: permitteeAddress
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || response.data;
    }
    throw new Error(response.data.status_details?.message || 'Revocation failed');
  }

  async getPermittees(bioassetSerial: string): Promise<any[]> {
    try {
      const response = await this.axios.get('/permittees', {
        params: { serial: bioassetSerial }
      });
      return response.data.permittees || response.data.data || [];
    } catch (error) {
      return [];
    }
  }

  async getMyPermissions(): Promise<any[]> {
    try {
      const signature = await this.getSignature();
      const response = await this.axios.get('/get_permitted_biosamples', {
        params: { signature }
      });
      return response.data.biosamples || response.data.data || [];
    } catch (error) {
      return [];
    }
  }

  // VCF Annotator endpoints
  async getVCFFiles(): Promise<any[]> {
    try {
      const signature = await this.getSignature();
      const response = await this.axios.get('/api_vcf_annotator/get_vcf_file_routes', {
        params: { user_signature: signature }
      });
      return response.data.files || response.data.data || [];
    } catch (error) {
      return [];
    }
  }

  // AlphaGenome endpoints
  async getMyAnalyses(): Promise<any[]> {
    try {
      const signature = await this.getSignature();
      const response = await this.axios.get('/api_alphagenome/get_my_analyses', {
        params: { user_signature: signature }
      });
      return response.data.analyses || response.data.data || [];
    } catch (error) {
      return [];
    }
  }

  // BioOS endpoints - Research Job Management
  async createBioOSJob(prompt: string, inputFiles: any[], pipeline?: any, metadata?: any): Promise<{ job_id: string; status: string; message: string }> {
    const signature = await this.getSignature();
    const response = await this.axios.post('/api_bioos/create_job', {
      user_signature: signature,
      prompt,
      input_files: inputFiles,
      pipeline,
      metadata
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || {};
    }
    throw new Error(response.data.status_details?.error || 'Failed to create job');
  }

  async getBioOSJobStatus(jobId: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.get('/api_bioos/job_status', {
      params: {
        user_signature: signature,
        job_id: jobId
      }
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || {};
    }
    throw new Error(response.data.status_details?.error || 'Failed to get job status');
  }

  async getBioOSJobResults(jobId: string): Promise<any> {
    const signature = await this.getSignature();
    const response = await this.axios.get('/api_bioos/job_results', {
      params: {
        user_signature: signature,
        job_id: jobId
      }
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || {};
    }
    throw new Error(response.data.status_details?.error || 'Failed to get job results');
  }

  async getBioOSPipelineList(): Promise<any> {
    const response = await this.axios.get('/api_bioos/pipeline_list');

    if (response.data.status === 'Success') {
      return response.data.status_details?.data || {};
    }
    throw new Error('Failed to get pipeline list');
  }

  async getBioOSUserJobs(): Promise<any[]> {
    const signature = await this.getSignature();
    const response = await this.axios.get('/api_bioos/user_jobs', {
      params: { user_signature: signature }
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.data?.jobs || [];
    }
    throw new Error(response.data.status_details?.error || 'Failed to get user jobs');
  }

  // ========================================
  // Dual NFT System - BioCID + Story Protocol
  // ========================================

  /**
   * Get approved research labs from registry
   * Labs must be verified to receive BioNFT-licensed genomic data
   */
  async getApprovedLabs(): Promise<any[]> {
    try {
      Logger.debug('Fetching approved labs from registry...');
      const response = await this.axios.get('/approved_labs');

      if (response.data.status === 'Success') {
        // Try multiple response patterns
        const labs = response.data.labs ||
                     response.data.status_details?.labs ||
                     response.data.data ||
                     [];

        // Normalize wallet field name
        return labs.map((lab: any) => ({
          ...lab,
          wallet_address: lab.wallet_address || lab.wallet
        }));
      }
      return [];
    } catch (error) {
      Logger.debug(`Error fetching approved labs: ${error}`);
      return [];
    }
  }

  /**
   * Calculate DNA fingerprint for VCF/genomic file
   * Uses vcf.genobank.app SNP fingerprinting algorithm
   */
  async calculateVCFFingerprint(params: {
    file_path: string;
    file_type?: string;
  }): Promise<{ fingerprint: string; algorithm: string } | null> {
    const signature = await this.getSignature();
    Logger.debug(`Calculating DNA fingerprint for ${params.file_path}...`);

    try {
      const response = await this.axios.get('/api_vcf_annotator/calculate_vcf_fingerprint', {
        params: {
          user_signature: signature,
          file_path: params.file_path,
          file_type: params.file_type || 'auto'
        }
      });

      if (response.data.status === 'Success') {
        const result = response.data.status_details;
        Logger.debug(`✅ Fingerprint calculated: ${result.fingerprint} (${result.algorithm})`);
        return {
          fingerprint: result.fingerprint,
          algorithm: result.algorithm
        };
      } else {
        Logger.debug(`⚠️ Could not calculate fingerprint: ${response.data.status_details?.message}`);
        return null;
      }
    } catch (error) {
      Logger.debug(`⚠️ Fingerprint calculation failed: ${error}`);
      return null;
    }
  }

  /**
   * Mint BioCID NFT on Sequentias Network
   * BioCID provides decentralized location addressing via Biorouter protocol
   */
  async mintSequentiasBioCID(params: {
    filename: string;
    file_type: string;
    s3_path: string;
    dna_fingerprint?: string;
    file_hash?: string;
  }): Promise<any> {
    const signature = await this.getSignature();
    Logger.debug('Minting BioCID on Sequentias Network...');

    const requestBody: any = {
      user_signature: signature,
      filename: params.filename,
      file_type: params.file_type,
      s3_path: params.s3_path
    };

    // Add optional fingerprint and hash if provided
    if (params.dna_fingerprint) {
      requestBody.dna_fingerprint = '0x' + params.dna_fingerprint;
    }
    if (params.file_hash) {
      requestBody.file_hash = '0x' + params.file_hash;
    }

    const response = await this.axios.post('/api_sequentias/mint_biocid', requestBody);

    // DEBUG: Log full response
    console.log('DEBUG mint_biocid response:', JSON.stringify(response.data, null, 2));

    if (response.data.status === 'Success') {
      // Try multiple response patterns:
      // 1. data field (standard pattern)
      // 2. status_details field (current backend pattern)
      // 3. status_details.data (nested pattern)
      const result = response.data.data || response.data.status_details || response.data.status_details?.data || response.data;
      console.log('DEBUG returning:', JSON.stringify(result, null, 2));
      return result;
    }
    throw new Error(response.data.message || 'Failed to mint BioCID');
  }

  /**
   * Register IP Asset on Story Protocol with BioCID reference
   * Links Story Protocol IP licensing to Sequentias location addressing
   */
  async registerIPAssetWithBiocid(params: {
    biocid: string;
    filename: string;
    file_type: string;
  }): Promise<any> {
    const signature = await this.getSignature();
    Logger.debug('Registering IP Asset on Story Protocol...');

    const response = await this.axios.post('/api_bioip/register_with_biocid', {
      user_signature: signature,
      biocid: params.biocid,
      filename: params.filename,
      file_type: params.file_type
    });

    // DEBUG: Log full response
    console.log('DEBUG register_with_biocid response:', JSON.stringify(response.data, null, 2));

    if (response.data.status === 'Success') {
      // Try multiple response patterns:
      // 1. data field (standard pattern)
      // 2. status_details field (current backend pattern)
      // 3. status_details.data (nested pattern)
      const result = response.data.data || response.data.status_details || response.data.status_details?.data || response.data;
      console.log('DEBUG returning:', JSON.stringify(result, null, 2));
      return result;
    }
    throw new Error(response.data.message || 'Failed to register IP Asset');
  }

  /**
   * Attach PIL (Programmable IP License) terms to IP Asset
   * Enables license token minting for authorized labs
   */
  async attachLicenseTerms(params: {
    ip_id: string;
    license_type: 'non-commercial' | 'commercial' | 'commercial-remix';
  }): Promise<any> {
    const signature = await this.getSignature();
    Logger.debug(`Attaching ${params.license_type} license terms...`);

    const response = await this.axios.post('/api_bioip/attach_license_terms', {
      user_signature: signature,
      ip_id: params.ip_id,
      license_type: params.license_type
    });

    // DEBUG: Log full response
    console.log('DEBUG attach_license_terms response:', JSON.stringify(response.data, null, 2));

    if (response.data.status === 'Success') {
      // Try multiple response patterns
      const result = response.data.data || response.data.status_details || response.data.status_details?.data || response.data;
      console.log('DEBUG returning:', JSON.stringify(result, null, 2));
      return result;
    }
    throw new Error(response.data.message || 'Failed to attach license terms');
  }

  /**
   * Share biofile with approved lab by minting license token
   * Creates NFT-gated access for GDPR-compliant data sharing
   */
  async shareWithLab(params: {
    ip_id: string;
    lab_wallet: string;
    license_type: 'non-commercial' | 'commercial' | 'commercial-remix';
  }): Promise<any> {
    const signature = await this.getSignature();
    Logger.debug(`Sharing IP Asset ${params.ip_id} with lab ${params.lab_wallet}...`);

    const response = await this.axios.post('/api_bioip/share_with_lab', {
      user_signature: signature,
      ip_id: params.ip_id,
      lab_wallet: params.lab_wallet,
      license_type: params.license_type
    });

    // DEBUG: Log full response
    console.log('DEBUG share_with_lab response:', JSON.stringify(response.data, null, 2));

    if (response.data.status === 'Success') {
      // Try multiple response patterns
      const result = response.data.data || response.data.status_details || response.data.status_details?.data || response.data;
      console.log('DEBUG returning:', JSON.stringify(result, null, 2));
      return result;
    }
    throw new Error(response.data.message || 'Failed to share with lab');
  }

  /**
   * Check if file already has BioCID
   * Prevents duplicate minting during share process
   */
  async checkExistingBiocid(filename: string): Promise<any | null> {
    try {
      const signature = await this.getSignature();
      Logger.debug(`Checking for existing BioCID: ${filename}`);

      const response = await this.axios.get('/api_sequentias/check_biocid', {
        params: {
          user_signature: signature,
          filename
        }
      });

      if (response.data.status === 'Success' && response.data.exists) {
        return response.data.data;
      }
      return null;
    } catch (error) {
      Logger.debug(`No existing BioCID found for ${filename}`);
      return null;
    }
  }

  async dissectAndShare(params: {
    phenotype_query: string;
    source_file: string;
    share_with?: string;
    license_type?: string;
    min_snps?: number;
    network?: string;  // 'sequentia', 'story', 'avalanche'
  }): Promise<any> {
    const signature = await this.getSignature();

    const response = await this.axios.post('/api_vcf_annotator/dissect_and_share', {
      user_signature: signature,
      phenotype_query: params.phenotype_query,
      source_file: params.source_file,
      share_with: params.share_with,
      license_type: params.license_type || 'non_commercial_social_remixing',
      min_snps: params.min_snps || 10,
      network: params.network || 'sequentia'  // Default: Sequentia
    }, {
      timeout: 180000  // 3 minutes for Claude AI processing
    });

    return response.data;
  }

  /**
   * Discover phenotype-specific SNPs using Claude Sonnet 4.5
   * Sequentia Protocol: AI-powered SNP discovery
   */
  async discoverPhenotypeSNPs(params: {
    phenotype: string;
    min_snps?: number;
  }): Promise<{ snps: any[] }> {
    const signature = await this.getSignature();

    const response = await this.axios.post('/api_vcf_annotator/discover_phenotype_snps', {
      user_signature: signature,
      phenotype_query: params.phenotype,
      min_snps: params.min_snps || 10
    }, {
      timeout: 180000  // 3 minutes for Claude AI processing
    });

    if (response.data.status === 'Success') {
      return { snps: response.data.status_details.snps || [] };
    }

    throw new Error(response.data.status_details?.message || 'SNP discovery failed');
  }

  /**
   * Get all biofiles (unified discovery across all sources)
   * Sequentia Protocol: BioCIDRegistry query
   */
  async getBiofiles(): Promise<any[]> {
    const signature = await this.getSignature();

    try {
      // Query all sources like biofile-unified.js
      const response = await this.axios.get('/get_my_uploaded_file_list', {
        params: { user_signature: signature }
      });

      if (response.data.status === 'Success') {
        return response.data.status_details?.data || [];
      }

      return [];
    } catch (error) {
      Logger.error(`Error fetching biofiles: ${error}`);
      return [];
    }
  }

  /**
   * Dissect with Sequentia Protocol (Backend signs with EXECUTOR!)
   *
   * User provides: user_signature (MetaMask - proves wallet ownership)
   * Backend signs: BioCID registration (SEQUENTIA_EXECUTOR_KEY pays gas)
   * User owns: The derivative BioCID
   *
   * SOLVES 0xd4d910b4 Story Protocol error!
   */
  async dissectSequentia(params: {
    phenotype_query: string;
    source_file: string;
    share_with?: string;
    license_type?: string;
    min_snps?: number;
  }): Promise<any> {
    const signature = await this.getSignature();

    const response = await this.axios.post('/api_vcf_annotator/dissect_sequentia', {
      user_signature: signature,
      phenotype_query: params.phenotype_query,
      source_file: params.source_file,
      share_with: params.share_with,
      license_type: params.license_type || 'non_commercial_social_remixing',
      min_snps: params.min_snps || 10
    }, {
      timeout: 180000  // 3 minutes
    });

    return response.data;
  }

  /**
   * View file content by BioCID or filename
   * GDPR Right to Access: Users can view their own genomic data
   */
  async viewFile(params: {
    biocid_or_filename: string;
    max_lines?: number;
  }): Promise<any> {
    const signature = await this.getSignature();

    const response = await this.axios.post('/api_vcf_annotator/view_file', {
      user_signature: signature,
      biocid_or_filename: params.biocid_or_filename,
      max_lines: params.max_lines || 0  // 0 = all lines
    });

    return response.data;
  }

  /**
   * Upload file to S3
   * Sequentia Protocol: Returns S3 path for BioCIDRegistry
   */
  async uploadFile(filePath: string): Promise<string> {
    const signature = await this.getSignature();
    const fs = require('fs');
    const FormData = require('form-data');

    const formData = new FormData();
    formData.append('user_signature', signature);
    formData.append('file', fs.createReadStream(filePath));

    const response = await this.axios.post('/upload_dataset_chunk', formData, {
      headers: formData.getHeaders(),
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    });

    if (response.data.status === 'Success') {
      return response.data.status_details?.s3_path || response.data.s3_path;
    }

    throw new Error('Upload failed');
  }

  /**
   * Download file from S3
   * Sequentia Protocol: With GDPR consent verification
   */
  async downloadFile(biocidOrFilename: string, destination: string): Promise<void> {
    const signature = await this.getSignature();
    const fs = require('fs');

    const response = await this.axios.get('/download_file', {
      params: {
        user_signature: signature,
        filename: biocidOrFilename
      },
      responseType: 'arraybuffer'
    });

    await fs.promises.writeFile(destination, response.data);
  }

  /**
   * Get Sequentia license tokens (BioPIL)
   */
  async getSequentiaLicenses(): Promise<any[]> {
    const signature = await this.getSignature();

    try {
      const response = await this.axios.get('/api_vcf_annotator/get_sequentia_licenses', {
        params: { user_signature: signature }
      });

      if (response.data.status === 'Success') {
        return response.data.status_details?.licenses || [];
      }

      return [];
    } catch (error) {
      Logger.debug(`Sequentia licenses query failed: ${error}`);
      return [];
    }
  }

  /**
   * Generate BioPIL contract via DNASign
   */
  async generateBioPILContract(params: {
    biocid: string;
    ip_asset_id?: string;
    permittee_wallet: string;
    permittee_name?: string;
    permittee_institution?: string;
    license_type: string;
    data_owner_wallet: string;
    data_owner_name?: string;
  }): Promise<any> {
    const response = await this.axios.post('/api_bioip/generate_biopil_contract', params);

    if (response.data.status === 'Success') {
      return response.data.status_details;
    }

    throw new Error(response.data.status_details?.message || 'Contract generation failed');
  }
}